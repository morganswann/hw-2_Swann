# Eval Set — Slack Message Formalizer

Each case includes a casual Slack input, the expected professional output, and grading criteria.

---

## Case 1
**Input:** `hey can u send me that thing we talked abt asap`  
**Expected:** `Hi, could you please send me the document we discussed at your earliest convenience? Thank you.`  
**Criteria:** Removes slang ("abt", "u"), replaces "asap" with a polite phrase, adds courteous tone.

---

## Case 2
**Input:** `yo the meeting got moved to 3 fyi`  
**Expected:** `Just a heads-up — the meeting has been rescheduled to 3:00 PM.`  
**Criteria:** Removes "yo" and "fyi", retains the key information (time change), professional phrasing.

---

## Case 3
**Input:** `i think the client is kinda upset abt the delay lol`  
**Expected:** `I believe the client may be concerned about the recent delay.`  
**Criteria:** Removes "kinda", "lol", "abt"; professional framing of a sensitive topic.

---

## Case 4
**Input:** `can someone pls fix the bug its been like forever`  
**Expected:** `Could someone please look into resolving this bug? It has been outstanding for quite some time.`  
**Criteria:** Removes hyperbole ("like forever"), adds proper punctuation, maintains urgency professionally.

---

## Case 5
**Input:** `btw i wont be in tmrw, just so u know`  
**Expected:** `Just a quick note — I will not be available tomorrow.`  
**Criteria:** Expands abbreviations ("btw", "tmrw", "u"), proper contraction expansion, clean sentence structure.

---

## Grading Rubric (per case)
| Dimension | Description |
|---|---|
| Accuracy | Does it preserve the original meaning? |
| Formality | Is slang, abbreviation, and casual tone removed? |
| Conciseness | Is it roughly the same length (not padded)? |
| Grammar | Is grammar, punctuation, and spelling correct? |
