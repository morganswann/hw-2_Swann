# Prompts

## Task
Slack Message Formalizer — convert casual workplace Slack messages into professional written communication.

---

## Prompt Version 1 (Initial)

**System Prompt:**
```
You are a professional business communication assistant. 
Your job is to rewrite casual Slack messages into polished, professional workplace emails or messages.
Keep the same meaning and intent, but use formal grammar, proper punctuation, and a respectful tone.
Do not add unnecessary filler. Return only the rewritten message, nothing else.
```

**User Prompt:**
```
Rewrite this message professionally:

{casual_message}
```

**Rationale:**  
The system prompt establishes the assistant's role clearly and gives explicit constraints (preserve meaning, no filler, return only the result). This prevents the model from adding explanations or commentary around the rewritten message.

---

## Prompt Version 2 (Iteration — if needed)

> To be filled in after evaluating Version 1 results. Possible changes:
> - Add tone guidance (e.g., "keep tone warm but professional, not cold or robotic")
> - Add length constraint (e.g., "aim for roughly the same length as the input")
> - Add output format (e.g., include greeting/sign-off for longer messages)
