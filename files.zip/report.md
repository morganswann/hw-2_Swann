# Report — Slack Message Formalizer

**Name:** Morgan Swann  
**Assignment:** HW 2  
**Task:** Slack Message Formalizer (casual → professional business messages)  
**LLM Used:** Claude (Anthropic API) — claude-opus-4-5  

---

## 1. Task Description

I built a Python prototype that takes casual Slack-style messages and rewrites them as professional workplace communications. This is a practical business writing task — many employees struggle to switch register between informal Slack chats and formal emails or memos.

---

## 2. Prompt Design

I used a system prompt to establish the assistant's role and constraints, and a simple user prompt template to pass in the casual message. See `prompts.md` for full prompt text and rationale.

**Key design decisions:**
- Instructed the model to return *only* the rewritten message (no preamble or explanation)
- Specified to preserve meaning and intent
- Kept it concise to avoid over-constraining the model

---

## 3. Eval Results

> Fill this in after running `app.py` and reviewing outputs.

| Case | Input (summary) | Pass/Fail | Notes |
|---|---|---|---|
| 1 | "send me that thing asap" | | |
| 2 | "meeting moved to 3 fyi" | | |
| 3 | "client is kinda upset lol" | | |
| 4 | "fix the bug its been forever" | | |
| 5 | "i wont be in tmrw" | | |

---

## 4. Prompt Iteration

> Fill in after reviewing eval results. Describe what changed between prompt versions and why.

**Version 1 → Version 2 changes:**
- 

**Effect of changes:**
- 

---

## 5. Honest Evaluation

> Reflect on where the model succeeded and where it fell short.

**Strengths:**
- 

**Weaknesses / Failure modes:**
- 

**What I would do with more time:**
- 
