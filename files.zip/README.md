# HW 2 — Slack Message Formalizer

A Python prototype that uses Claude (Anthropic API) to convert casual Slack messages into professional business communications.

## Setup

1. Install dependencies:
```bash
pip install anthropic
```

2. Set your Anthropic API key:
```bash
export ANTHROPIC_API_KEY=your_key_here
```

3. Run the app:
```bash
python app.py
```

## Files

| File | Description |
|---|---|
| `app.py` | Main script — runs eval cases and interactive mode |
| `prompts.md` | Prompt versions and design rationale |
| `eval_set.md` | Test cases with expected outputs and grading rubric |
| `report.md` | Evaluation results and reflection |
